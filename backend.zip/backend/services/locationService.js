/**
 * Location Service for parsing Google Maps URLs and extracting coordinates
 */
const axios = require('axios');

class LocationService {
  /**
   * Resolve shortened URLs by following redirects
   */
  static async resolveShortUrl(url) {
    try {
      const response = await axios.get(url, {
        maxRedirects: 5,
        timeout: 10000,
        validateStatus: () => true, // Accept any status code
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
      });
      // Return the final URL after redirects
      const finalUrl = response.request.res?.responseUrl || response.request?.res?.responseURL || url;
      console.log('[LocationService.resolveShortUrl] Original:', url, 'Final:', finalUrl);
      return finalUrl;
    } catch (error) {
      console.error('[LocationService.resolveShortUrl] Error:', error.message);
      return url; // Return original URL if resolution fails
    }
  }

  /**
   * Parse Google Maps URL to extract latitude and longitude
   * Supports various Google Maps URL formats
   */
  static async parseGoogleMapsUrl(url) {
    try {
      console.log('[LocationService.parseGoogleMapsUrl] Parsing URL:', url);
      
      // Handle shortened URLs (maps.app.goo.gl, goo.gl)
      if (url.includes('maps.app.goo.gl') || url.includes('goo.gl')) {
        url = await this.resolveShortUrl(url);
        console.log('[LocationService.parseGoogleMapsUrl] Resolved URL:', url);
      }

      const urlObj = new URL(url);
      console.log('[LocationService.parseGoogleMapsUrl] URL Object:', {
        pathname: urlObj.pathname,
        search: urlObj.search,
        hash: urlObj.hash
      });
      
      // Format 1: https://maps.google.com/?q=lat,lng
      if (urlObj.searchParams.has('q')) {
        const q = urlObj.searchParams.get('q');
        console.log('[LocationService.parseGoogleMapsUrl] q param:', q);
        const coords = q.match(/^(-?\d+\.?\d*),(-?\d+\.?\d*)$/);
        if (coords) {
          return {
            latitude: parseFloat(coords[1]),
            longitude: parseFloat(coords[2]),
            source: 'url_q_param'
          };
        }
      }

      // Format 2: https://maps.google.com/?ll=lat,lng
      if (urlObj.searchParams.has('ll')) {
        const ll = urlObj.searchParams.get('ll');
        console.log('[LocationService.parseGoogleMapsUrl] ll param:', ll);
        const coords = ll.match(/^(-?\d+\.?\d*),(-?\d+\.?\d*)$/);
        if (coords) {
          return {
            latitude: parseFloat(coords[1]),
            longitude: parseFloat(coords[2]),
            source: 'url_ll_param'
          };
        }
      }

      // Format 3: https://www.google.com/maps/@lat,lng,zoom
      const pathMatch = urlObj.pathname.match(/@(-?\d+\.?\d*),(-?\d+\.?\d*)/);
      if (pathMatch) {
        console.log('[LocationService.parseGoogleMapsUrl] Path match:', pathMatch);
        return {
          latitude: parseFloat(pathMatch[1]),
          longitude: parseFloat(pathMatch[2]),
          source: 'url_path'
        };
      }

      // Format 4: https://maps.google.com/place/.../@lat,lng,zoom
      const placeMatch = urlObj.href.match(/@(-?\d+\.?\d*),(-?\d+\.?\d*)/);
      if (placeMatch) {
        console.log('[LocationService.parseGoogleMapsUrl] Place match:', placeMatch);
        return {
          latitude: parseFloat(placeMatch[1]),
          longitude: parseFloat(placeMatch[2]),
          source: 'url_place'
        };
      }

      // Format 5: Extract from data parameter (new Google Maps format)
      if (urlObj.searchParams.has('data')) {
        const data = urlObj.searchParams.get('data');
        console.log('[LocationService.parseGoogleMapsUrl] data param:', data);
        // Try to extract coordinates from encoded data
        const coordMatch = data.match(/!3d(-?\d+\.?\d*)!4d(-?\d+\.?\d*)/);
        if (coordMatch) {
          return {
            latitude: parseFloat(coordMatch[1]),
            longitude: parseFloat(coordMatch[2]),
            source: 'url_data_param'
          };
        }
      }

      // Format 6: Check hash for coordinates (newer Google Maps format)
      if (urlObj.hash) {
        console.log('[LocationService.parseGoogleMapsUrl] Hash:', urlObj.hash);
        const hashMatch = urlObj.hash.match(/!3d(-?\d+\.?\d*)!4d(-?\d+\.?\d*)/);
        if (hashMatch) {
          return {
            latitude: parseFloat(hashMatch[1]),
            longitude: parseFloat(hashMatch[2]),
            source: 'url_hash'
          };
        }
      }

      console.log('[LocationService.parseGoogleMapsUrl] No matching format found');
      return null;
    } catch (error) {
      console.error('[LocationService.parseGoogleMapsUrl] Error:', error);
      return null;
    }
  }

  /**
   * Validate coordinates
   */
  static validateCoordinates(lat, lng) {
    if (typeof lat !== 'number' || typeof lng !== 'number') {
      return false;
    }
    if (lat < -90 || lat > 90) {
      return false;
    }
    if (lng < -180 || lng > 180) {
      return false;
    }
    return true;
  }

  /**
   * Extract location from URL or return manual coordinates
   */
  static async extractLocation(locationInput) {
    // If input is already coordinates object
    if (typeof locationInput === 'object' && locationInput.latitude && locationInput.longitude) {
      if (this.validateCoordinates(locationInput.latitude, locationInput.longitude)) {
        return {
          latitude: locationInput.latitude,
          longitude: locationInput.longitude,
          source: 'manual'
        };
      }
      return null;
    }

    // If input is a URL, try to parse it
    if (typeof locationInput === 'string' && locationInput.startsWith('http')) {
      const parsed = await this.parseGoogleMapsUrl(locationInput);
      if (parsed && this.validateCoordinates(parsed.latitude, parsed.longitude)) {
        return parsed;
      }
      return null;
    }

    // If input is a string with lat,lng format
    if (typeof locationInput === 'string') {
      const coords = locationInput.match(/^(-?\d+\.?\d*),(-?\d+\.?\d*)$/);
      if (coords) {
        const lat = parseFloat(coords[1]);
        const lng = parseFloat(coords[2]);
        if (this.validateCoordinates(lat, lng)) {
          return {
            latitude: lat,
            longitude: lng,
            source: 'manual_string'
          };
        }
      }
    }

    return null;
  }

  /**
   * Get error message for invalid location input
   */
  static getErrorMessage(input) {
    if (!input) {
      return 'Location is required';
    }

    if (typeof input === 'string' && input.startsWith('http')) {
      return 'Invalid Google Maps URL. Please use a valid Google Maps link with coordinates.';
    }

    if (typeof input === 'string') {
      return 'Invalid coordinates format. Please use format: latitude,longitude (e.g., 24.8607,67.0011)';
    }

    if (typeof input === 'object') {
      if (!input.latitude || !input.longitude) {
        return 'Both latitude and longitude are required';
      }
      return 'Invalid coordinates. Latitude must be between -90 and 90, longitude between -180 and 180';
    }

    return 'Invalid location input';
  }
}

module.exports = LocationService;
